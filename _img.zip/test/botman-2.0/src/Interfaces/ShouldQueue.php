<?php

namespace BotMan\BotMan\Interfaces;

interface ShouldQueue
{
    //
}
