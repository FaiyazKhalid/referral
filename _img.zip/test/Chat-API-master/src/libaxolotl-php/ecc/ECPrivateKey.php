<?php

interface ECPrivateKey
{
    public function serialize();

    public function getType();
}
