   <div class="footer">
        <div class="row no-gutters justify-content-center">
            <div class="col-auto">
                <a href="index.php" class="active">
                    <i class="material-icons">home</i>
                    <p>Home</p>
                </a>
            </div>
            <div class="col-auto">
                <a href="refer_friends.php" class="">
                    <i class="material-icons">shopping_bag</i>
                    <p>Refer</p>
                </a>
            </div>
            <div class="col-auto">
                <a href="analytics.php" class="">
                    <i class="material-icons">insert_chart_outline</i>
                    <p>Analytics</p>
                </a>
            </div>
            <div class="col-auto">
                <a href="scan.php" class="">
                    <i class="material-icons">account_balance_wallet</i>
                    <p>Scan</p>
                </a>
            </div>
            
            <div class="col-auto">
                <a href="profile.php" class="">
                    <i class="material-icons">account_circle</i>
                    <p>Profile</p>
                </a>
            </div>
        </div>
    </div>