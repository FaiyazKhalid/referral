<?
 $Plan0 = 0;
if ($row['points'] == $Plan0 ) {
      include("locked.php");
     
    } else {
        
        include("request_extend.php");
    
    }
?>

