<?php
$forename = $_GET['v'];
$surname = $_GET['w'];
?>
----------
<input id='v' type='text' value='<?php echo $forename; ?>' >
<input id='w' type='text' value='<?php echo $surname; ?>' >