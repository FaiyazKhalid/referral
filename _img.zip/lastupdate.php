Last Update: 
<?
//Example Y-m-d H:i:s date string.
echo $row['updation_date'];


?>