<?php
$dbhost = "localhost"; //MySQL host
$dbuser = "faiyazkh_money"; //MySQL username
$dbpass = "9971217372Fk"; //MySQL password
$dbname = "faiyazkh_money"; //MySQL database name
$installdir = "https://onetbank.com"; //EZRefer's install directory (no slash at the end)
?>