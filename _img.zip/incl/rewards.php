<?php
 if ($row['points'] >= 1000) {
     
     include("request_button.php");
    } else {
    include("locked.php");
    }
   

?>