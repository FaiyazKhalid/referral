<?
if (($t == "100" and $m > "-100" ))  {
$expirydate= date('d-m-Y H:i:s', strtotime($date .' +10 day'));
$deduct = 100; 
date_default_timezone_set("Asia/Kolkata");
    $currentdate = date('d-m-Y H:i:s');
    $eusername = $_SESSION['username'];

} elseif (($t == "500" and $m > "-500"  )) {
$expirydate= date('d-m-Y H:i:s', strtotime($date .' +15 day'));
$deduct = 500;
date_default_timezone_set("Asia/Kolkata");
    $currentdate = date('d-m-Y H:i:s');
    $eusername = $_SESSION['username'];
    
} elseif (($t == "1000" and $transection > "0" and $m > "-1000" )) {
$expirydate= date('d-m-Y H:i:s', strtotime($date .' +20 day'));
$deduct = 1000;
date_default_timezone_set("Asia/Kolkata");
    $currentdate = date('d-m-Y H:i:s');
    $eusername = $_SESSION['username'];

} elseif (($t == "5000" and $transection == "1" and $period < "2")) {
$expirydate= date('d-m-Y H:i:s', strtotime($date .' +1 day'));
$deduct = 0;
date_default_timezone_set("Asia/Kolkata");
    $currentdate = date('d-m-Y H:i:s');
    $eusername = $_SESSION['username'];

} elseif (($t == "10000" and $transection > "0" and $m > "-10000")) {
$expirydate= date('d-m-Y H:i:s', strtotime($date .' +60 day'));
$deduct = 10000;
date_default_timezone_set("Asia/Kolkata");
    $currentdate = date('d-m-Y H:i:s');
    $eusername = $_SESSION['username'];

} else {
  include("core/zero-transection.php");
}

?>