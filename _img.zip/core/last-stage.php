<?

if (($t == "100" and $transection == "0" and $period < "1" ))  {
$expirydate= date('d-m-Y H:i:s', strtotime($date .' +10 day'));
$deduct = 100; 
date_default_timezone_set("Asia/Kolkata");
    $currentdate = date('d-m-Y H:i:s');
    $eusername = $_SESSION['username'];

} elseif (($t == "500" and $transection == "0" and $period < "1" )) {
$expirydate= date('d-m-Y H:i:s', strtotime($date .' +15 day'));
$deduct = 500;
date_default_timezone_set("Asia/Kolkata");
    $currentdate = date('d-m-Y H:i:s');
    $eusername = $_SESSION['username'];
    
} elseif (($t == "1000" and $transection == "0" and $period < "1")) {
$expirydate= date('d-m-Y H:i:s', strtotime($date .' +20 day'));
$deduct = 1000;
date_default_timezone_set("Asia/Kolkata");
    $currentdate = date('d-m-Y H:i:s');
    $eusername = $_SESSION['username'];

} elseif (($t == "5000" and $transection > "0" and $period < "3" )) {
$expirydate= date('d-m-Y H:i:s', strtotime($date .' +3 day'));
$deduct = 5000;
date_default_timezone_set("Asia/Kolkata");
    $currentdate = date('d-m-Y H:i:s');
    $eusername = $_SESSION['username'];

} elseif (($t == "10000" and $transection == "0" and $period < "1" )) {
$expirydate= date('d-m-Y H:i:s', strtotime($date .' +60 day'));
$deduct = 10000;
date_default_timezone_set("Asia/Kolkata");
    $currentdate = date('d-m-Y H:i:s');
    $eusername = $_SESSION['username'];

} else {
  echo "<center><h2><a href='pay.php'>Pay to Extend Period</a></h2></center><br>";
  
}
?>